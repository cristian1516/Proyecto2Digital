Core/Src/personajes_flash.o: ../Core/Src/personajes_flash.c \
 ../Core/Src/personajes_flash.h
../Core/Src/personajes_flash.h:
