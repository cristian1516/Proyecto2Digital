################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/fatfs_sd.c \
../Core/Src/fondo.c \
../Core/Src/font.c \
../Core/Src/game.c \
../Core/Src/graficos.c \
../Core/Src/ili9341.c \
../Core/Src/main.c \
../Core/Src/personajes.c \
../Core/Src/personajes_flash.c \
../Core/Src/pj_cammy.c \
../Core/Src/pj_chunglee.c \
../Core/Src/pj_deejay.c \
../Core/Src/pj_ryu.c \
../Core/Src/recursos.c \
../Core/Src/sprites.c \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c 

OBJS += \
./Core/Src/fatfs_sd.o \
./Core/Src/fondo.o \
./Core/Src/font.o \
./Core/Src/game.o \
./Core/Src/graficos.o \
./Core/Src/ili9341.o \
./Core/Src/main.o \
./Core/Src/personajes.o \
./Core/Src/personajes_flash.o \
./Core/Src/pj_cammy.o \
./Core/Src/pj_chunglee.o \
./Core/Src/pj_deejay.o \
./Core/Src/pj_ryu.o \
./Core/Src/recursos.o \
./Core/Src/sprites.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o 

C_DEPS += \
./Core/Src/fatfs_sd.d \
./Core/Src/fondo.d \
./Core/Src/font.d \
./Core/Src/game.d \
./Core/Src/graficos.d \
./Core/Src/ili9341.d \
./Core/Src/main.d \
./Core/Src/personajes.d \
./Core/Src/personajes_flash.d \
./Core/Src/pj_cammy.d \
./Core/Src/pj_chunglee.d \
./Core/Src/pj_deejay.d \
./Core/Src/pj_ryu.d \
./Core/Src/recursos.d \
./Core/Src/sprites.d \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../FATFS/Target -I../FATFS/App -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FatFs/src -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/fatfs_sd.cyclo ./Core/Src/fatfs_sd.d ./Core/Src/fatfs_sd.o ./Core/Src/fatfs_sd.su ./Core/Src/fondo.cyclo ./Core/Src/fondo.d ./Core/Src/fondo.o ./Core/Src/fondo.su ./Core/Src/font.cyclo ./Core/Src/font.d ./Core/Src/font.o ./Core/Src/font.su ./Core/Src/game.cyclo ./Core/Src/game.d ./Core/Src/game.o ./Core/Src/game.su ./Core/Src/graficos.cyclo ./Core/Src/graficos.d ./Core/Src/graficos.o ./Core/Src/graficos.su ./Core/Src/ili9341.cyclo ./Core/Src/ili9341.d ./Core/Src/ili9341.o ./Core/Src/ili9341.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/personajes.cyclo ./Core/Src/personajes.d ./Core/Src/personajes.o ./Core/Src/personajes.su ./Core/Src/personajes_flash.cyclo ./Core/Src/personajes_flash.d ./Core/Src/personajes_flash.o ./Core/Src/personajes_flash.su ./Core/Src/pj_cammy.cyclo ./Core/Src/pj_cammy.d ./Core/Src/pj_cammy.o ./Core/Src/pj_cammy.su ./Core/Src/pj_chunglee.cyclo ./Core/Src/pj_chunglee.d ./Core/Src/pj_chunglee.o ./Core/Src/pj_chunglee.su ./Core/Src/pj_deejay.cyclo ./Core/Src/pj_deejay.d ./Core/Src/pj_deejay.o ./Core/Src/pj_deejay.su ./Core/Src/pj_ryu.cyclo ./Core/Src/pj_ryu.d ./Core/Src/pj_ryu.o ./Core/Src/pj_ryu.su ./Core/Src/recursos.cyclo ./Core/Src/recursos.d ./Core/Src/recursos.o ./Core/Src/recursos.su ./Core/Src/sprites.cyclo ./Core/Src/sprites.d ./Core/Src/sprites.o ./Core/Src/sprites.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su

.PHONY: clean-Core-2f-Src

