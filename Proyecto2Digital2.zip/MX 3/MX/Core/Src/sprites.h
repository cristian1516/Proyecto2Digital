/*
 * sprites.h - Personajes del juego.
 *
 * Cada personaje es un archivo .SPR (lo genera herramientas/convertir.py a
 * partir de sprites.c) que se guarda comprimido en la flash
 * (personajes_flash.c, ver herramientas/spr_a_c.py). Se usa ahí mismo, sin
 * copiarlo a la RAM (personajes.c).
 *
 * Cada personaje tiene una lista de cuadros por animación. Un cuadro es una
 * imagen de w x h con 1 byte por píxel: cada byte es un índice a la paleta
 * del personaje y el índice 0 es transparente. Los píxeles van por filas, de
 * arriba hacia abajo y de izquierda a derecha. En la RAM cada cuadro está
 * comprimido; game.c descomprime el que toca dibujar en un búfer de cada
 * jugador (solo cuando el cuadro cambia).
 *
 * Los cuadros no miden todos lo mismo, el de la patada es mucho más ancho
 * que el de la guardia, así que cada uno dice cómo se coloca respecto al
 * cuerpo del personaje:
 *
 *   - Los pies están en la última fila del cuadro: esa fila va en el piso.
 *   - "eje" es cuántas columnas del cuadro quedan DETRÁS del centro del
 *     cuerpo. Todos los personajes están dibujados mirando a la derecha;
 *     al voltearlos, esas columnas quedan del otro lado del centro.
 *	   Esquemático:
 *        eje                     centro del cuerpo
 *     |<            >|                        |
 *     +        +                 +       v
 *     |  espalda    brazo      > |   [ cuerpo ] > zona que golpea
 *     +        +                 +
 *
 * El cuerpo (cuerpoW x cuerpoH) es la caja que se usa para las colisiones.
 * Es más angosta que el dibujo: las manos y los pies sobresalen de ella.
 * Ryu y Dee Jay tienen la misma caja y la misma estatura (Dee Jay está
 * achicado a la altura de Ryu).
 *
 * Los cuadros de KO se colocan distinto: el borde de adelante del cuadro va
 * en el frente del cuerpo y lo demás queda detrás, porque el peleador
 * cae hacia atrás desde donde estaba parado.
 */
#ifndef INC_SPRITES_H_
#define INC_SPRITES_H_

#include <stdint.h>

/* Un cuadro de animación */
typedef struct {
	const uint8_t *datos; /* w * h índices de paleta (0 = transparente),
	                         comprimidos (ver recursos.h)                    */
	uint16_t tam;         /* bytes comprimidos                               */
	uint8_t  w, h;        /* tamaño del cuadro, en píxeles                   */
	uint8_t  eje;         /* columnas que quedan detrás del centro del cuerpo */
} Cuadro;

/* Una animación: lista de cuadros. Con n = 0 el personaje no la tiene. */
typedef struct {
	const Cuadro *cuadros;
	uint8_t  n;
	uint8_t  activo;      /* solo en los ataques: el cuadro del golpe, con el
	                         brazo o la pierna extendidos. Los cuadros de
	                         antes son la preparación; los de después, si
	                         hay, son para recoger el brazo o la pierna     */
} Animacion;

/* Zona que hace daño mientras el ataque está activo: un rectángulo delante
 * del personaje. Ryu y Dee Jay usan la misma: el promedio de lo que da el
 * sprite de cada uno (lo que el brazo o la pierna sobresalen de la guardia),
 * así los dos pegan con el mismo alcance. Para que un ataque llegue más o
 * menos lejos basta con cambiar su ancho (w) en la tabla del personaje. */
typedef struct {
	uint8_t  dx;          /* del centro del cuerpo a donde empieza, hacia adelante */
	uint8_t  dy;          /* de la parte de arriba del cuerpo hacia abajo          */
	uint8_t  w, h;
} ZonaGolpe;

typedef struct {
	char      nombre[16];     /* el que se ve en el menú                     */
	const uint16_t *paleta;   /* colores RGB565 (la entrada 0 no se usa)     */
	const uint16_t *paletas;  /* todas las paletas del archivo, seguidas     */
	uint16_t  nColores;       /* colores de cada paleta                      */
	uint8_t   nPaletas;
	uint16_t  maxCuadro;      /* w * h del cuadro más grande: lo que mide el
	                             búfer donde se descomprime                  */
	uint8_t   cuerpoW;        /* caja de colisión del cuerpo                 */
	uint8_t   cuerpoH;
	uint8_t   margen;         /* lo más que el dibujo sobresale por detrás
	                             del cuerpo: el cuerpo no se acerca más que
	                             esto al borde de la pantalla                */
	Animacion caminar;        /* el cuadro 0 es también la pose en guardia   */
	Animacion ko;             /* caída al perder: los cuadros se ven una vez,
	                             en orden, y el último (tendido en el piso)
	                             se queda. Si n = 0, se dibuja un rectángulo  */
	Animacion cubre;          /* cubriéndose: los cuadros se repiten mientras
	                             dura. Si n = 0, se ve la guardia             */
	Animacion dano;           /* al recibir un golpe: los cuadros se ven una
	                             vez, en orden. Si n = 0, se ve la guardia
	                             toda en blanco                              */
	Animacion ataque[2];      /* [0] golpe, [1] patada. Si n = 0, el ataque
	                             se dibuja como un rectángulo                */
	ZonaGolpe zona[2];        /* [0] golpe, [1] patada                       */
	Animacion salto;          /* en el aire: los cuadros se reparten según la
	                             velocidad vertical, del despegue (cuadro 0)
	                             al aterrizaje (el último). Si n = 0, se ve
	                             la guardia                                  */
} Personaje;


#endif /* INC_SPRITES_H_ */
