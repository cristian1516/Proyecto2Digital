Core/Src/sintetizador.o: ../Core/Src/sintetizador.c \
 ../Core/Inc/sintetizador.h ../Core/Inc/musica.h ../Core/Inc/sonidos.h
../Core/Inc/sintetizador.h:
../Core/Inc/musica.h:
../Core/Inc/sonidos.h:
