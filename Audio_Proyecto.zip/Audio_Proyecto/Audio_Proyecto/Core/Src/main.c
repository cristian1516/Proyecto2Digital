/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Nucleo de audio (STM32F446RE): música 8 bits y efectos.
 ******************************************************************************
 * Recibe comandos de 1 byte de la Nucleo del juego por USART1 (PA10) y
 * genera el sonido por el DAC (PA4). el audio está en audio.c y
 * sintetizador.c.
 *
 * Este archivo reemplaza al main.c que genera CubeMX. No usa nada que haya
 * que activar en el .ioc: reloj, DAC, TIM6, DMA y USART1 se configuran en
 * código. El botón azul (PC13) y el LED verde (PA5) también los maneja
 * audio.c.
 ******************************************************************************
 */
/* USER CODE END Header */
#include "main.h"

/* USER CODE BEGIN Includes */
#include "audio.h"
/* USER CODE END Includes */

void SystemClock_Config(void);

int main(void)
{
  /* Reinicia los periféricos, la flash y el SysTick (HAL_GetTick) */
  HAL_Init();

  /* Reloj: 84 MHz a partir del oscilador interno (HSI). audio.c calcula
   * sus velocidades con el reloj real, así que también funciona con otro. */
  SystemClock_Config();

  /* USER CODE BEGIN 2 */
  Audio_Init();       /* DAC + TIM6 + DMA + USART1: desde aquí ya suena */
  /* USER CODE END 2 */

  while (1)
  {
    /* USER CODE BEGIN 3 */
    Audio_Tarea();    /* botón de prueba y LED; el audio va por interrupciones */
    /* USER CODE END 3 */
  }
}

/**
  * @brief Reloj del sistema: HSI (16 MHz) -> PLL -> 84 MHz.
  *        APB1 = 42 MHz (timers 84 MHz), APB2 = 84 MHz.
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                              | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Si algo falla al configurar el reloj: se queda aquí con el LED
  *         verde (PA5) encendido.
  */
void Error_Handler(void)
{
  __disable_irq();
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
  GPIOA->MODER = (GPIOA->MODER & ~(3u << (5 * 2))) | (1u << (5 * 2));
  GPIOA->BSRR = 1u << 5;
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void) file;
  (void) line;
}
#endif /* USE_FULL_ASSERT */
