/*
 * musica.c - Canciones de la Nucleo de audio (generado con componer.py).
 * sínfonías generadas con IA (cita en el informe)
 * Formato: ver musica.h. Cada línea es un compás de 4/4 (suma 16).
 * Todas son composiciones originales.
 */
#include "musica.h"

/* ---- Menú de inicio: épica, en La menor ---- */
static const uint8_t tituloMelodia[] = {
			/* Anacrusa   */ A4,2, B4,2,
		    /* Tema 1     */ C5,4, A4,4, E5,4, C5,2, A4,2,
		    /* Tema 2     */ D5,4, B4,4, G5,4, D5,2, B4,2,
		    /* Bajada 1   */ E5,2, D5,2, C5,2, B4,2, A4,4, C5,4,
		    /* Bajada 2   */ E5,2, D5,2, C5,2, B4,2, A4,4, E4,4,
		    /* Remate esc.*/ E4,2, F4,2, G4,2, B4,2,
		    /* Tan, Tan!  */ A4,4, E4,4,
		    /* Final      */ A4,8, SIL,4
};
static const uint8_t tituloBajo[] = {
		/* El bajo toca la Tónica (Raíz) y la Quinta alternadas para dar ritmo de Polka */
		    /* Anacrusa   */ SIL,4,
		    /* Tema 1     */ A2,4, E3,4, A2,4, E3,4,
		    /* Tema 2     */ G2,4, D3,4, G2,4, D3,4,
		    /* Bajada 1   */ A2,4, E3,4, A2,4, E3,4,
		    /* Bajada 2   */ E2,4, B2,4, A2,4, E3,4,
		    /* Remate esc.*/ E2,2, F2,2, G2,2, B2,2,   /* El bajo hace la misma escala que la melodía aquí */
		    /* Tan, Tan!  */ A2,4, E2,4,               /* Golpes fuertes al unísono */
		    /* Final      */ A2,8, SIL,4
};
static const uint8_t tituloBateria[] = {
		/* Batería: Bombo (BOM) en el tiempo fuerte, Caja/Platillo en el contratiempo */
		    /* Anacrusa   */ SIL,2, CAJ,2,
		    /* Tema 1     */ BOM,2, PLA,2, BOM,2, CAJ,2, BOM,2, PLA,2, BOM,2, CAJ,2,
		    /* Tema 2     */ BOM,2, PLA,2, BOM,2, CAJ,2, BOM,2, PLA,2, BOM,2, CAJ,2,
		    /* Bajada 1   */ BOM,2, PLA,2, BOM,2, CAJ,2, BOM,2, PLA,2, BOM,2, CAJ,2,
		    /* Bajada 2   */ BOM,2, PLA,2, BOM,2, CAJ,2, BOM,2, PLA,2, BOM,2, CAJ,2,
		    /* Remate esc.*/ BOM,2, BOM,2, BOM,2, BOM,2, /* Acompaña la tensión de la escala */
		    /* Tan, Tan!  */ CAJ,4, BOM,4,
		    /* Final      */ PLA,8, SIL,4
};
const Cancion cancionTitulo = { "TITULO", 120, { { tituloMelodia, sizeof tituloMelodia / 2 }, { tituloBajo, sizeof tituloBajo / 2 }, { tituloBateria, sizeof tituloBateria / 2 } } };

/* ---- Elegir personaje y mapa: alegre, en Do mayor ---- */
static const uint8_t elegirMelodia[] = {
	C5,2, E5,2, G5,2, E5,2, C5,2, E5,2, G5,4,
	A5,2, G5,2, F5,2, E5,2, D5,4, SIL,4,
	B4,2, D5,2, F5,2, D5,2, B4,2, D5,2, F5,4,
	E5,2, D5,2, C5,2, B4,2, C5,4, SIL,4,
	C5,2, E5,2, G5,2, E5,2, C5,2, E5,2, G5,4,
	A5,2, G5,2, F5,2, E5,2, D5,4, SIL,4,
	G4,2, B4,2, D5,2, F5,2, E5,2, D5,2, C5,4,
	C5,8, SIL,8,
};
static const uint8_t elegirBajo[] = {
	C3,4, G2,4, C3,4, G2,4,
	F2,4, C3,4, F2,4, C3,4,
	G2,4, D3,4, G2,4, D3,4,
	C3,4, G2,4, C3,4, G2,4,
	C3,4, G2,4, C3,4, G2,4,
	F2,4, C3,4, F2,4, C3,4,
	G2,4, D3,4, G2,4, D3,4,
	C3,4, G2,4, C3,4, G2,4,
};
static const uint8_t elegirBateria[] = {
	BOM,2, PLA,2, CAJ,2, PLA,2, BOM,2, PLA,2, CAJ,2, PLA,2,
};
const Cancion cancionElegir = { "ELEGIR", 120, { { elegirMelodia, sizeof elegirMelodia / 2 }, { elegirBajo, sizeof elegirBajo / 2 }, { elegirBateria, sizeof elegirBateria / 2 } } };

/* ---- Pantalla del ganador: fanfarria ---- */
static const uint8_t ganadorMelodia[] = {
	G4,2, G4,2, G4,2, C5,10,
	A4,2, A4,2, A4,2, F5,10,
	G4,2, B4,2, D5,2, G5,6, F5,2, D5,2,
	E5,2, G5,2, C6,8, SIL,4,
};
static const uint8_t ganadorBajo[] = {
	C3,4, C3,4, G2,4, C3,4,
	F2,4, F2,4, C3,4, F2,4,
	G2,4, G2,4, D3,4, G2,4,
	C3,8, G2,4, C3,4,
};
static const uint8_t ganadorBateria[] = {
	BOM,4, CAJ,4, BOM,4, CAJ,2, CAJ,2,
};
const Cancion cancionGanador = { "GANADOR", 130, { { ganadorMelodia, sizeof ganadorMelodia / 2 }, { ganadorBajo, sizeof ganadorBajo / 2 }, { ganadorBateria, sizeof ganadorBateria / 2 } } };

/* ---- Mapa CASA ANGEL: ritmo caribeño, en Sol mayor ---- */
static const uint8_t casaAngelMelodia[] = {
	SIL,2, B4,2, D5,2, B4,2, G4,4, A4,2, B4,2,
	C5,2, SIL,2, E5,2, C5,2, G4,4, SIL,4,
	SIL,2, A4,2, D5,2, FS5,2, E5,4, D5,2, C5,2,
	B4,6, A4,2, G4,4, SIL,4,
	SIL,2, D5,2, G5,2, D5,2, B4,4, D5,2, E5,2,
	E5,2, SIL,2, G5,2, E5,2, C5,4, SIL,2, C5,2,
	A4,2, B4,2, C5,2, D5,2, FS5,4, E5,2, D5,2,
	G5,8, SIL,8,
};
static const uint8_t casaAngelBajo[] = {
	G2,4, SIL,2, G2,2, B2,2, D3,2, SIL,2, G2,2,
	C3,4, SIL,2, C3,2, E3,2, G3,2, SIL,2, C3,2,
	D3,4, SIL,2, D3,2, FS3,2, A3,2, SIL,2, D3,2,
	G2,4, SIL,2, G2,2, B2,2, D3,2, SIL,2, G2,2,
};
static const uint8_t casaAngelBateria[] = {
	PLA,2, PLA,2, PLA,2, PLA,2, BOM,2, PLA,2, CAJ,2, PLA,2,
};
const Cancion cancionCasaAngel = { "CASA ANGEL", 100, { { casaAngelMelodia, sizeof casaAngelMelodia / 2 }, { casaAngelBajo, sizeof casaAngelBajo / 2 }, { casaAngelBateria, sizeof casaAngelBateria / 2 } } };

/* ---- Mapa CASA PALALA: escala japonesa y tambores taiko ---- */
static const uint8_t casaPalalaMelodia[] = {
	D5,4, E5,2, F5,2, A5,4, F5,2, E5,2,
	D5,6, A4,2, AS4,4, A4,4,
	F5,4, E5,2, D5,2, E5,4, F5,2, A5,2,
	AS5,8, A5,4, SIL,4,
	D6,4, AS5,2, A5,2, F5,4, E5,2, F5,2,
	A5,4, F5,2, E5,2, D5,4, AS4,4,
	A4,2, AS4,2, D5,2, E5,2, F5,2, E5,2, D5,2, AS4,2,
	D5,12, SIL,4,
};
static const uint8_t casaPalalaBajo[] = {
	D2,4, A2,4, D3,4, A2,4,
	D2,4, A2,4, D3,4, A2,4,
	D2,4, A2,4, D3,4, A2,4,
	AS2,4, F2,4, AS2,4, F2,4,
	D2,4, A2,4, D3,4, A2,4,
	D2,4, A2,4, D3,4, A2,4,
	A2,4, E2,4, A2,4, E2,4,
	D2,4, A2,4, D3,4, A2,4,
};
static const uint8_t casaPalalaBateria[] = {
	BOM,4, BOM,2, BOM,2, CAJ,4, BOM,2, PLA,2,
	BOM,2, BOM,2, BOM,4, CAJ,2, CAJ,2, CAJ,4,
};
const Cancion cancionCasaPalala = { "CASA PALALA", 132, { { casaPalalaMelodia, sizeof casaPalalaMelodia / 2 }, { casaPalalaBajo, sizeof casaPalalaBajo / 2 }, { casaPalalaBateria, sizeof casaPalalaBateria / 2 } } };

/* Música de cada mapa, en el orden de los escenarios de la SD (por nombre
 * de archivo: FONDO.ESC = CASA ANGEL, HONDA.ESC = CASA PALALA). Si hay más
 * mapas que canciones, se repiten en orden. */
const Cancion *const cancionesMapa[] = { &cancionCasaAngel, &cancionCasaPalala };
const uint8_t nCancionesMapa = sizeof cancionesMapa / sizeof cancionesMapa[0];
