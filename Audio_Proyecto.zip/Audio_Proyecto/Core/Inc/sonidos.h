/*
 * sonidos.h - Comandos de sonido entre las dos Nucleo.
 *
 * La Nucleo del juego manda UN byte por UART (115200, 8N1) a la Nucleo de
 * audio cada vez que algo debe sonar. Este mismo archivo va en los dos
 * proyectos: si se cambia en uno, copiarlo al otro.
 *
 *   0x00          silencio (para la música)
 *   0x01 - 0x0F   efectos: suenan ENCIMA de la música, sin cortarla
 *   0x10 - 0x1F   música de las pantallas
 *   0x20 - 0x3F   música de cada mapa (0x20 = primer escenario de la SD,
 *                 0x21 = el segundo...). Si hay más mapas que canciones,
 *                 se repiten en orden.
 *
 * Si llega la misma canción que ya está sonando, no vuelve a empezar (así
 * ir y venir entre los menús no la reinicia).
 */
#ifndef SONIDOS_H_
#define SONIDOS_H_

enum {
	SND_SILENCIO = 0x00,

	/* Efectos */
	SND_GOLPE    = 0x01,   /* golpe que conecta              */
	SND_PATADA   = 0x02,   /* patada que conecta             */
	SND_CUBRE    = 0x03,   /* golpe o patada cubiertos       */
	SND_KO       = 0x04,   /* el que pierde cae              */
	SND_SALTO    = 0x05,   /* despegue del salto             */
	SND_CURSOR   = 0x06,   /* mover la selección en un menú  */
	SND_ELEGIR   = 0x07,   /* confirmar en un menú           */
	SND_ATAQUE   = 0x08,   /* lanzar golpe o patada (al aire) */

	/* Música de las pantallas */
	MUS_TITULO   = 0x10,   /* menú de inicio                 */
	MUS_ELEGIR   = 0x11,   /* elegir personajes y escenario  */
	MUS_GANADOR  = 0x12,   /* pantalla del ganador           */

	/* Música de los mapas: MUS_MAPA + número de escenario */
	MUS_MAPA     = 0x20
};

#endif /* SONIDOS_H_ */
