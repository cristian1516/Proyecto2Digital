/*
 * audio.h - Hardware de la Nucleo de audio (STM32F446RE).
 *
 *   PA4  -> DAC canal 1: salida de audio hacia el amplificador TDA2030A
 *   PA10 <- USART1 RX:   comandos de la Nucleo del juego (su PC12, UART5 TX)
 *   PC13    botón azul B1: prueba sin la otra Nucleo (cambia de canción)
 *   PA5     LED verde LD2: parpadea cada vez que llega un comando
 *
 * TIM6 dispara el DAC 16000 veces por segundo y el DMA le pasa las muestras
 * de un búfer circular. Cuando el DMA va a la mitad del búfer, la
 * interrupción calcula la mitad que ya se tocó (doble búfer): el
 * procesador solo trabaja cada 8 ms y el sonido nunca se corta.
 *
 * NO activar en CubeMX: DAC, TIM6, USART1 ni DMA1 (este archivo los
 * configura y define sus interrupciones; si CubeMX también las genera, el
 * compilador dirá "multiple definition").
 */
#ifndef AUDIO_H_
#define AUDIO_H_

#include <stdint.h>

/* Llamar una vez después de SystemClock_Config() */
void Audio_Init(void);

/* Llamar en el while(1): atiende el botón de prueba y el LED */
void Audio_Tarea(void);

#endif /* AUDIO_H_ */
