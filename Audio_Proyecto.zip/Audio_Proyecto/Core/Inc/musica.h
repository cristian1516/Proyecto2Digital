/*
 * musica.h - Formato de las canciones (los datos están en musica.c).
 *
 * Cada canción tiene 3 voces y cada voz es una lista de pares
 *      nota, duración
 *   - nota: número de nota (C4 = 60 es el DO central, ver la tabla de
 *     abajo). 0 = silencio. En la voz de batería: BOM (bombo), CAJ (caja),
 *     PLA (platillo).
 *   - duración: en semicorcheas (1/16). 4 = una negra, 16 = un compás de 4/4.
 *
 * Cada voz se repite sola al terminar, así que el bajo y la batería pueden
 * ser un patrón corto (1 o 2 compases) y la melodía más larga.
 */
#ifndef MUSICA_H_
#define MUSICA_H_

#include <stdint.h>

typedef struct {
	const uint8_t *datos;    /* pares nota, duración */
	uint16_t pares;          /* cuántos pares */
} Voz;

typedef struct {
	const char *nombre;
	uint8_t bpm;             /* negras por minuto */
	Voz voz[3];              /* 0 melodía, 1 bajo, 2 batería */
} Cancion;

/* Canciones de las pantallas (sonidos.h: MUS_TITULO, MUS_ELEGIR, MUS_GANADOR) */
extern const Cancion cancionTitulo, cancionElegir, cancionGanador;

/* Canciones de los mapas, en el orden de los escenarios de la SD */
extern const Cancion *const cancionesMapa[];
extern const uint8_t nCancionesMapa;

/* Notas. DO = C, RE = D, MI = E, FA = F, SOL = G, LA = A, SI = B;
 * S = sostenido (CS4 = DO#4). El número es la octava. */
enum {
	C2 = 36, CS2, D2, DS2, E2, F2, FS2, G2, GS2, A2, AS2, B2,
	C3, CS3, D3, DS3, E3, F3, FS3, G3, GS3, A3, AS3, B3,
	C4, CS4, D4, DS4, E4, F4, FS4, G4, GS4, A4, AS4, B4,
	C5, CS5, D5, DS5, E5, F5, FS5, G5, GS5, A5, AS5, B5,
	C6, CS6, D6, DS6, E6, F6, FS6, G6, GS6, A6, AS6, B6,
	SIL = 0,                     /* silencio */
	BOM = 1, CAJ = 2, PLA = 3    /* batería */
};

#endif /* MUSICA_H_ */
