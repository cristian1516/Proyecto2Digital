/*
 * sintetizador.h - Música 8 bits y efectos, mezclados en una sola señal.
 *
 * No depende del hardware: solo calcula muestras. audio.c las manda al DAC.
 *
 *   - Música: 3 voces que tocan las canciones de musica.c
 *       0 melodía  (onda cuadrada)
 *       1 bajo     (onda triangular)
 *       2 batería  (ruido y un tono que baja, para el bombo)
 *   - Efectos: 1 voz más que suena encima. La música sigue mientras tanto:
 *     las dos señales se suman muestra por muestra.
 */
#ifndef SINTETIZADOR_H_
#define SINTETIZADOR_H_

#include <stdint.h>

#define SINT_FS        16000u   /* muestras por segundo */

void Sint_Iniciar(void);

/* Recibe un comando de sonidos.h. Se puede llamar desde una interrupción:
 * solo lo guarda en una cola y Sint_Generar lo atiende. */
void Sint_Comando(uint8_t c);

/* Llena "n" muestras de 12 bits (0 a 4095, silencio = 2048) */
void Sint_Generar(uint16_t *destino, uint16_t n);

/* Volumen general de 0 a 16 (16 = máximo). Empieza en 12. */
void Sint_Volumen(uint8_t v);

#endif /* SINTETIZADOR_H_ */
