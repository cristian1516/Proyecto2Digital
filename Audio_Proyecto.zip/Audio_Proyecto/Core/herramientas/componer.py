# componer.py - Escribe las canciones de la Nucleo de audio en Core/Src/musica.c.
# Uso: python componer.py   (después recompilar y grabar la Nucleo de audio)
# Formato de cada compás: "NOTA:duración ..." (duración en semicorcheas, el
# compás suma 16). "-" = silencio. Batería: BOM, CAJ, PLA.
# Genera musica.c a partir de las partituras de abajo (formato: nota:duración)
import os
canciones = {
 'Titulo': dict(nombre='TITULO', bpm=140, desc='Menú de inicio: épica, en La menor', voces=[
  # melodía, 8 compases
  ["A4:4 C5:2 E5:2 D5:4 C5:2 B4:2", "A4:6 E4:2 A4:4 B4:4", "C5:4 D5:2 E5:2 G5:4 F5:2 E5:2", "D5:8 -:4 E5:4",
   "F5:4 E5:2 D5:2 C5:4 B4:2 C5:2", "D5:4 C5:2 B4:2 A4:4 G4:4", "A4:2 C5:2 E5:2 A5:2 G5:4 E5:4", "A5:12 -:4"],
  # bajo: Lam Lam Do Sol Fa Sol Lam Lam
  ["A2:2 A3:2 A2:2 A3:2 A2:2 A3:2 A2:2 A3:2"]*2 + ["C3:2 C4:2 C3:2 C4:2 C3:2 C4:2 C3:2 C4:2", "G2:2 G3:2 G2:2 G3:2 G2:2 G3:2 G2:2 G3:2",
   "F2:2 F3:2 F2:2 F3:2 F2:2 F3:2 F2:2 F3:2", "G2:2 G3:2 G2:2 G3:2 G2:2 G3:2 G2:2 G3:2"] + ["A2:2 A3:2 A2:2 A3:2 A2:2 A3:2 A2:2 A3:2"]*2,
  ["BOM:2 PLA:2 CAJ:2 PLA:2 BOM:2 BOM:2 CAJ:2 PLA:2"]]),
 'Elegir': dict(nombre='ELEGIR', bpm=120, desc='Elegir personaje y mapa: alegre, en Do mayor', voces=[
  ["C5:2 E5:2 G5:2 E5:2 C5:2 E5:2 G5:4", "A5:2 G5:2 F5:2 E5:2 D5:4 -:4", "B4:2 D5:2 F5:2 D5:2 B4:2 D5:2 F5:4", "E5:2 D5:2 C5:2 B4:2 C5:4 -:4",
   "C5:2 E5:2 G5:2 E5:2 C5:2 E5:2 G5:4", "A5:2 G5:2 F5:2 E5:2 D5:4 -:4", "G4:2 B4:2 D5:2 F5:2 E5:2 D5:2 C5:4", "C5:8 -:8"],
  ["C3:4 G2:4 C3:4 G2:4", "F2:4 C3:4 F2:4 C3:4", "G2:4 D3:4 G2:4 D3:4", "C3:4 G2:4 C3:4 G2:4"]*2,
  ["BOM:2 PLA:2 CAJ:2 PLA:2 BOM:2 PLA:2 CAJ:2 PLA:2"]]),
 'Ganador': dict(nombre='GANADOR', bpm=130, desc='Pantalla del ganador: fanfarria', voces=[
  ["G4:2 G4:2 G4:2 C5:10", "A4:2 A4:2 A4:2 F5:10", "G4:2 B4:2 D5:2 G5:6 F5:2 D5:2", "E5:2 G5:2 C6:8 -:4"],
  ["C3:4 C3:4 G2:4 C3:4", "F2:4 F2:4 C3:4 F2:4", "G2:4 G2:4 D3:4 G2:4", "C3:8 G2:4 C3:4"],
  ["BOM:4 CAJ:4 BOM:4 CAJ:2 CAJ:2"]]),
 'CasaAngel': dict(nombre='CASA ANGEL', bpm=100, desc='Mapa CASA ANGEL: ritmo caribeño, en Sol mayor', voces=[
  ["-:2 B4:2 D5:2 B4:2 G4:4 A4:2 B4:2", "C5:2 -:2 E5:2 C5:2 G4:4 -:4", "-:2 A4:2 D5:2 FS5:2 E5:4 D5:2 C5:2", "B4:6 A4:2 G4:4 -:4",
   "-:2 D5:2 G5:2 D5:2 B4:4 D5:2 E5:2", "E5:2 -:2 G5:2 E5:2 C5:4 -:2 C5:2", "A4:2 B4:2 C5:2 D5:2 FS5:4 E5:2 D5:2", "G5:8 -:8"],
  ["G2:4 -:2 G2:2 B2:2 D3:2 -:2 G2:2", "C3:4 -:2 C3:2 E3:2 G3:2 -:2 C3:2", "D3:4 -:2 D3:2 FS3:2 A3:2 -:2 D3:2", "G2:4 -:2 G2:2 B2:2 D3:2 -:2 G2:2"],
  ["PLA:2 PLA:2 PLA:2 PLA:2 BOM:2 PLA:2 CAJ:2 PLA:2"]]),
 'CasaPalala': dict(nombre='CASA PALALA', bpm=132, desc='Mapa CASA PALALA: escala japonesa y tambores taiko', voces=[
  ["D5:4 E5:2 F5:2 A5:4 F5:2 E5:2", "D5:6 A4:2 AS4:4 A4:4", "F5:4 E5:2 D5:2 E5:4 F5:2 A5:2", "AS5:8 A5:4 -:4",
   "D6:4 AS5:2 A5:2 F5:4 E5:2 F5:2", "A5:4 F5:2 E5:2 D5:4 AS4:4", "A4:2 AS4:2 D5:2 E5:2 F5:2 E5:2 D5:2 AS4:2", "D5:12 -:4"],
  ["D2:4 A2:4 D3:4 A2:4"]*3 + ["AS2:4 F2:4 AS2:4 F2:4"] + ["D2:4 A2:4 D3:4 A2:4"]*2 + ["A2:4 E2:4 A2:4 E2:4", "D2:4 A2:4 D3:4 A2:4"],
  ["BOM:4 BOM:2 BOM:2 CAJ:4 BOM:2 PLA:2", "BOM:2 BOM:2 BOM:4 CAJ:2 CAJ:2 CAJ:4"]]),
}
mapas = ['CasaAngel', 'CasaPalala']
NOMBRES_VOZ = ['Melodia', 'Bajo', 'Bateria']

def pares(compases):
    out = []
    for i, c in enumerate(compases):
        toks = c.split()
        total = 0
        fila = []
        for t in toks:
            n, d = t.split(':'); d = int(d); total += d
            fila.append(('SIL' if n == '-' else n, d))
        assert total == 16, (c, total)
        out.append(fila)
    return out

lineas = ['/*', ' * musica.c - Canciones de la Nucleo de audio (generado con componer.py).', ' *',
          ' * Formato: ver musica.h. Cada línea es un compás de 4/4 (suma 16).', ' * Todas son composiciones originales.', ' */',
          '#include "musica.h"', '']
for clave, c in canciones.items():
    lineas.append(f'/* ---- {c["desc"]} ---- */')
    for k, comp in enumerate(c['voces']):
        nombre = f'{clave[0].lower()+clave[1:]}{NOMBRES_VOZ[k]}'
        lineas.append(f'static const uint8_t {nombre}[] = {{')
        for fila in pares(comp):
            lineas.append('\t' + ' '.join(f'{n},{d},' for n, d in fila))
        lineas.append('};')
    v = ', '.join(f'{{ {clave[0].lower()+clave[1:]}{NOMBRES_VOZ[k]}, sizeof {clave[0].lower()+clave[1:]}{NOMBRES_VOZ[k]} / 2 }}' for k in range(3))
    lineas.append(f'const Cancion cancion{clave} = {{ "{c["nombre"]}", {c["bpm"]}, {{ {v} }} }};')
    lineas.append('')
lineas.append('/* Música de cada mapa, en el orden de los escenarios de la SD (por nombre')
lineas.append(' * de archivo: FONDO.ESC = CASA ANGEL, HONDA.ESC = CASA PALALA). Si hay más')
lineas.append(' * mapas que canciones, se repiten en orden. */')
lineas.append('const Cancion *const cancionesMapa[] = { ' + ', '.join('&cancion' + m for m in mapas) + ' };')
lineas.append('const uint8_t nCancionesMapa = sizeof cancionesMapa / sizeof cancionesMapa[0];')
src = '\n'.join(lineas) + '\n'
# extern de las de mapa en el .h no hace falta: se usan solo aquí
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'Core', 'Src', 'musica.c'), 'w').write(src)
print('ok', len(src))
