/*
 * audio.c - DAC + TIM6 + DMA + USART1 de la Nucleo de audio. Ver audio.h.
 *
 * Se configura con registros (CMSIS) para no depender de lo que se active
 * en CubeMX. Las velocidades se calculan con el reloj real del micro, así
 * que funciona con cualquier SystemClock_Config.
 */
#include "stm32f4xx_hal.h"
#include "audio.h"
#include "sintetizador.h"
#include "sonidos.h"

#define BAUDIOS   115200u
#define N_BUF     256u              /* 2 mitades de 128 muestras = 8 ms cada una */

static uint16_t bufer[N_BUF];
static volatile uint32_t ultimoComando;   /* HAL_GetTick() del último byte */

void Audio_Init(void) {
	uint32_t pclk1, timclk;

	Sint_Iniciar();
	Sint_Generar(bufer, N_BUF);             /* el búfer empieza en silencio */

	/* Relojes */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN | RCC_AHB1ENR_DMA1EN;
	RCC->APB1ENR |= RCC_APB1ENR_DACEN | RCC_APB1ENR_TIM6EN;
	RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
	(void) RCC->APB2ENR;                    /* esperar a que se activen */

	/* PA4 analógico (salida del DAC) */
	GPIOA->MODER |= 3u << (4 * 2);
	GPIOA->PUPDR &= ~(3u << (4 * 2));
	/* PA10 función alterna 7 = USART1_RX, con pull-up */
	GPIOA->MODER = (GPIOA->MODER & ~(3u << (10 * 2))) | (2u << (10 * 2));
	GPIOA->AFR[1] = (GPIOA->AFR[1] & ~(0xFu << ((10 - 8) * 4))) | (7u << ((10 - 8) * 4));
	GPIOA->PUPDR = (GPIOA->PUPDR & ~(3u << (10 * 2))) | (1u << (10 * 2));
	/* PA5 salida (LED LD2) */
	GPIOA->MODER = (GPIOA->MODER & ~(3u << (5 * 2))) | (1u << (5 * 2));
	/* PC13 entrada (botón B1; la Nucleo ya tiene su resistencia) */
	GPIOC->MODER &= ~(3u << (13 * 2));

	/* DMA1 Stream 5, canal 7 = DAC1: memoria -> DAC, circular, 16 bits */
	DMA1_Stream5->CR = 0;
	while (DMA1_Stream5->CR & DMA_SxCR_EN)
		;
	DMA1->HIFCR = DMA_HIFCR_CTCIF5 | DMA_HIFCR_CHTIF5 | DMA_HIFCR_CTEIF5
	            | DMA_HIFCR_CDMEIF5 | DMA_HIFCR_CFEIF5;
	DMA1_Stream5->PAR  = (uint32_t) &DAC->DHR12R1;
	DMA1_Stream5->M0AR = (uint32_t) bufer;
	DMA1_Stream5->NDTR = N_BUF;
	DMA1_Stream5->CR = (7u << DMA_SxCR_CHSEL_Pos) | DMA_SxCR_MSIZE_0 | DMA_SxCR_PSIZE_0
	                 | DMA_SxCR_MINC | DMA_SxCR_CIRC | DMA_SxCR_DIR_0
	                 | DMA_SxCR_HTIE | DMA_SxCR_TCIE;
	DMA1_Stream5->CR |= DMA_SxCR_EN;
	NVIC_SetPriority(DMA1_Stream5_IRQn, 1);
	NVIC_EnableIRQ(DMA1_Stream5_IRQn);

	/* DAC canal 1: lo dispara TIM6 (TSEL1 = 000) y pide datos al DMA */
	DAC->DHR12R1 = 2048;
	DAC->CR = DAC_CR_TEN1 | DAC_CR_DMAEN1;
	DAC->CR |= DAC_CR_EN1;

	/* TIM6: un evento cada 1/16000 s. Si APB1 está dividido, el reloj de
	 * los timers es el doble de PCLK1. */
	pclk1 = HAL_RCC_GetPCLK1Freq();
	timclk = ((RCC->CFGR & RCC_CFGR_PPRE1) == RCC_CFGR_PPRE1_DIV1) ? pclk1 : 2u * pclk1;
	TIM6->PSC = 0;
	TIM6->ARR = (timclk + SINT_FS / 2u) / SINT_FS - 1u;
	TIM6->CR2 = TIM_CR2_MMS_1;              /* actualización -> TRGO (al DAC) */
	TIM6->EGR = TIM_EGR_UG;
	TIM6->CR1 = TIM_CR1_CEN;

	/* USART1: solo recibe, 115200 8N1, con interrupción */
	USART1->BRR = (HAL_RCC_GetPCLK2Freq() + BAUDIOS / 2u) / BAUDIOS;
	USART1->CR1 = USART_CR1_UE | USART_CR1_RE | USART_CR1_RXNEIE;
	NVIC_SetPriority(USART1_IRQn, 2);
	NVIC_EnableIRQ(USART1_IRQn);
}

/* El DMA terminó una mitad del búfer: calcularla de nuevo mientras toca la otra */
void DMA1_Stream5_IRQHandler(void) {
	uint32_t isr = DMA1->HISR;
	if (isr & DMA_HISR_HTIF5) {
		DMA1->HIFCR = DMA_HIFCR_CHTIF5;
		Sint_Generar(bufer, N_BUF / 2u);
	}
	if (isr & DMA_HISR_TCIF5) {
		DMA1->HIFCR = DMA_HIFCR_CTCIF5;
		Sint_Generar(bufer + N_BUF / 2u, N_BUF / 2u);
	}
	if (isr & (DMA_HISR_TEIF5 | DMA_HISR_DMEIF5 | DMA_HISR_FEIF5))
		DMA1->HIFCR = DMA_HIFCR_CTEIF5 | DMA_HIFCR_CDMEIF5 | DMA_HIFCR_CFEIF5;
}

/* Llegó un byte de la Nucleo del juego */
void USART1_IRQHandler(void) {
	uint32_t sr = USART1->SR;
	if (sr & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE)) {
		uint8_t b = (uint8_t) USART1->DR;   /* leer DR limpia los errores */
		if ((sr & USART_SR_RXNE) && !(sr & (USART_SR_FE | USART_SR_NE))) {
			Sint_Comando(b);
			ultimoComando = HAL_GetTick();
		}
	}
}

/* Botón de prueba: cada vez que se presiona suena lo siguiente de la lista */
static const uint8_t PRUEBA[] = {
	MUS_TITULO, MUS_ELEGIR, SND_CURSOR, SND_ELEGIR, MUS_MAPA + 0, SND_GOLPE,
	SND_PATADA, MUS_MAPA + 1, SND_CUBRE, SND_SALTO, SND_KO, MUS_GANADOR, SND_SILENCIO
};

void Audio_Tarea(void) {
	static uint8_t antes = 1, k = 0;
	static uint32_t cambio;
	uint8_t ahora = (GPIOC->IDR & (1u << 13)) ? 1 : 0;   /* 0 = presionado */
	uint32_t t = HAL_GetTick();

	if (ahora != antes && t - cambio > 30u) {             /* antirrebote */
		cambio = t;
		antes = ahora;
		if (ahora == 0) {
			Sint_Comando(PRUEBA[k]);
			ultimoComando = t;
			k = (uint8_t) ((k + 1u) % sizeof PRUEBA);
		}
	}
	/* LED: encendido 50 ms después de cada comando */
	if (t - ultimoComando < 50u)
		GPIOA->BSRR = 1u << 5;
	else
		GPIOA->BSRR = 1u << (5 + 16);
}
