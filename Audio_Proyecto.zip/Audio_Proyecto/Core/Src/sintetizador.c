/*
 * sintetizador.c - Música 8 bits y efectos de sonido. Ver sintetizador.h.
 *
 * Todo es aritmética entera por muestra:
 *   - Cada voz tiene un acumulador de fase de 32 bits: en cada muestra se le
 *     suma "inc" y el bit más alto dice en qué mitad de la onda va. Con
 *     inc = f * 2^32 / FS la onda tiene frecuencia f.
 *   - El ruido sale de un registro de desplazamiento (LFSR) de 16 bits.
 *   - Las voces se suman, se recortan a 12 bits y se centran en 2048.
 */
#include <math.h>
#include "sintetizador.h"
#include "musica.h"
#include "sonidos.h"

/* Volumen de cada voz (la suma de todas cabe en ±2047) */
#define A_MELODIA   520
#define A_BAJO      560
#define A_BATERIA   430
#define A_EFECTO    820

#define MS(x)       ((uint32_t) (x) * SINT_FS / 1000u)

/* ---- Utilidades ---------------------------------------------------------- */

static uint32_t incNota[128];     /* incremento de fase de cada nota */
static uint16_t lfsr = 0xACE1u;

static inline int32_t Ruido(void) {
	lfsr = (uint16_t) ((lfsr >> 1) ^ (-(int16_t) (lfsr & 1u) & 0xB400u));
	return (lfsr & 1u) ? 1 : -1;
}

/* Triangular de -1024 a +1024 a partir de la fase */
static inline int32_t Triangular(uint32_t fase) {
	uint32_t v = (fase & 0x80000000u) ? ~fase : fase;   /* 0 .. 2^31 */
	return (int32_t) (v >> 20) - 1024;
}

static inline uint32_t IncHz(uint32_t hz) {
	return (uint32_t) (((uint64_t) hz << 32) / SINT_FS);
}

/* ---- Cola de comandos (la llena la interrupción de la UART) ---------------- */

static volatile uint8_t cola[16];
static volatile uint8_t colaIn, colaOut;

void Sint_Comando(uint8_t c) {
	uint8_t sig = (uint8_t) ((colaIn + 1u) & 15u);
	if (sig != colaOut) {             /* si está llena, se pierde el comando */
		cola[colaIn] = c;
		colaIn = sig;
	}
}

/* ---- Música --------------------------------------------------------------- */

typedef struct {
	const Voz *voz;
	uint16_t i;          /* par que está sonando */
	uint32_t resta;      /* muestras que le faltan a la nota */
	uint32_t dur;        /* muestras que dura la nota completa */
	uint32_t t;          /* muestras desde que empezó la nota */
	uint32_t fase, inc;
	uint8_t  nota;
} Canal;

static const Cancion *cancion;
static Canal canal[3];
static uint32_t muestrasSemi;     /* muestras por semicorchea */

static void SiguienteNota(Canal *c) {
	const Voz *v = c->voz;
	if (v->pares == 0) {
		c->nota = SIL;
		c->resta = 0xFFFFFFFFu;
		return;
	}
	c->i = (uint16_t) ((c->i + 1u) % v->pares);
	c->nota = v->datos[2u * c->i];
	c->dur = c->resta = (uint32_t) v->datos[2u * c->i + 1u] * muestrasSemi;
	c->t = 0;
	if (c->nota >= 12 && c->nota < 128)
		c->inc = incNota[c->nota];
}

static void EmpezarCancion(const Cancion *s) {
	cancion = s;
	if (s == 0)
		return;
	muestrasSemi = SINT_FS * 60u / (s->bpm * 4u);
	for (uint8_t k = 0; k < 3; k++) {
		canal[k].voz = &s->voz[k];
		canal[k].i = (uint16_t) (s->voz[k].pares - 1u);   /* la siguiente es la 0 */
		canal[k].fase = 0;
		SiguienteNota(&canal[k]);
	}
}

/* Melodía: cuadrada con un poco de caída de volumen y un hueco al final de
 * cada nota para que se distingan las notas repetidas. */
static inline int32_t MuestraMelodia(Canal *c) {
	int32_t a;
	uint32_t hueco = c->dur / 8u;
	if (c->nota < 12 || c->resta < hueco)
		return 0;
	c->fase += c->inc;
	/* volumen: de 256 baja a 150 en los primeros 150 ms */
	a = (c->t < MS(150)) ? 256 - (int32_t) (106u * c->t / MS(150)) : 150;
	return ((c->fase & 0x80000000u) ? A_MELODIA : -A_MELODIA) * a / 256;
}

static inline int32_t MuestraBajo(Canal *c) {
	uint32_t hueco = c->dur / 10u;
	if (c->nota < 12 || c->resta < hueco)
		return 0;
	c->fase += c->inc;
	return Triangular(c->fase) * A_BAJO / 1024;
}

static inline int32_t MuestraBateria(Canal *c) {
	uint32_t t = c->t;
	switch (c->nota) {
	case BOM:                                   /* tono que baja de 160 a 45 Hz */
		if (t >= MS(130))
			return 0;
		c->fase += IncHz(160u - 115u * t / MS(130));
		return Triangular(c->fase) * A_BATERIA * (int32_t) (MS(130) - t)
		       / (1024 * (int32_t) MS(130)) * 2;
	case CAJ:                                   /* ruido + un poco de tono */
		if (t >= MS(120))
			return 0;
		c->fase += IncHz(190);
		return (Ruido() * A_BATERIA + (t < MS(40) ? Triangular(c->fase) * A_BATERIA / 2048 : 0))
		       * (int32_t) (MS(120) - t) / (int32_t) MS(120);
	case PLA:                                   /* ruido corto */
		if (t >= MS(35))
			return 0;
		return Ruido() * (A_BATERIA / 2) * (int32_t) (MS(35) - t) / (int32_t) MS(35);
	default:
		return 0;
	}
}

/* ---- Efectos --------------------------------------------------------------- */

typedef struct {
	uint16_t ms;         /* duración */
	uint16_t f0, f1;     /* el tono va de f0 a f1 Hz (0 = sin tono) */
	uint8_t  tono;       /* volumen del tono, 0 a 16 */
	uint8_t  ruido;      /* volumen del ruido, 0 a 16 */
	uint8_t  grave;      /* el ruido cambia cada "grave" muestras (más = más grave) */
	uint8_t  pasos;      /* 0 = barrido continuo; n = el tono salta en n pasos */
} Efecto;

static const Efecto EFECTOS[] = {
	/*                 ms   f0    f1  tono ruido grave pasos */
	[SND_GOLPE]    = {  90, 320,  140,  10,   14,    2,    0 },
	[SND_PATADA]   = { 140, 220,   70,  12,   14,    4,    0 },
	[SND_CUBRE]    = {  60, 1400, 1100, 10,    4,    1,    0 },
	[SND_KO]       = { 900, 700,   55,  14,    8,    6,    0 },
	[SND_SALTO]    = { 140, 300,  900,   8,    0,    1,    0 },
	[SND_CURSOR]   = {  40, 1000, 1000,  9,    0,    1,    0 },
	[SND_ELEGIR]   = { 160, 800,  1600, 10,    0,    1,    2 },
	[SND_ATAQUE]   = {  70, 0,      0,   0,    6,    1,    0 },
};
#define N_EFECTOS  (sizeof EFECTOS / sizeof EFECTOS[0])

static const Efecto *efecto;
static uint32_t efT, efDur, efFase;
static int32_t  efRuido;

static void EmpezarEfecto(uint8_t id) {
	if (id >= N_EFECTOS || EFECTOS[id].ms == 0)
		return;
	efecto = &EFECTOS[id];
	efT = 0;
	efDur = MS(efecto->ms);
	efFase = 0;
}

static inline int32_t MuestraEfecto(void) {
	const Efecto *e = efecto;
	int32_t s = 0, vol;
	uint32_t f;
	if (e == 0)
		return 0;
	if (efT >= efDur) {
		efecto = 0;
		return 0;
	}
	vol = (int32_t) (efDur - efT) * 256 / (int32_t) efDur;      /* 256 -> 0 */
	if (e->tono && e->f0) {
		uint32_t avance = efT;
		if (e->pasos)                                            /* escalones */
			avance = efT * e->pasos / efDur * efDur / e->pasos;
		f = (uint32_t) ((int32_t) e->f0 + ((int32_t) e->f1 - (int32_t) e->f0)
		                * (int32_t) (avance / 16u) / (int32_t) (efDur / 16u));
		efFase += IncHz(f);
		s += ((efFase & 0x80000000u) ? 1 : -1) * A_EFECTO * e->tono / 16;
	}
	if (e->ruido) {
		if (efT % e->grave == 0)
			efRuido = Ruido();
		s += efRuido * A_EFECTO * e->ruido / 16;
	}
	efT++;
	return s * vol / 256;
}

/* ---- Comandos y mezcla ------------------------------------------------------- */

static uint8_t volumen = 12;

void Sint_Volumen(uint8_t v) {
	volumen = (v > 16) ? 16 : v;
}

static void Atender(uint8_t c) {
	const Cancion *nueva = 0;
	if (c == SND_SILENCIO) {
		cancion = 0;
		efecto = 0;
		return;
	}
	if (c < 0x10) {
		EmpezarEfecto(c);
		return;
	}
	if (c == MUS_TITULO)       nueva = &cancionTitulo;
	else if (c == MUS_ELEGIR)  nueva = &cancionElegir;
	else if (c == MUS_GANADOR) nueva = &cancionGanador;
	else if (c >= MUS_MAPA && c < MUS_MAPA + 0x20 && nCancionesMapa > 0)
		nueva = cancionesMapa[(c - MUS_MAPA) % nCancionesMapa];
	if (nueva != 0 && nueva != cancion)   /* la misma: no vuelve a empezar */
		EmpezarCancion(nueva);
}

void Sint_Iniciar(void) {
	for (uint8_t n = 12; n < 128; n++)
		incNota[n] = (uint32_t) (440.0 * pow(2.0, (n - 69) / 12.0) * 4294967296.0 / SINT_FS);
	cancion = 0;
	efecto = 0;
	colaIn = colaOut = 0;
}

void Sint_Generar(uint16_t *destino, uint16_t n) {
	while (colaOut != colaIn) {
		Atender(cola[colaOut]);
		colaOut = (uint8_t) ((colaOut + 1u) & 15u);
	}

	for (uint16_t k = 0; k < n; k++) {
		int32_t s = 0;
		if (cancion != 0) {
			s += MuestraMelodia(&canal[0]);
			s += MuestraBajo(&canal[1]);
			s += MuestraBateria(&canal[2]);
			if (efecto != 0)
				s = s * 3 / 4;               /* la música baja un poco mientras suena un efecto */
			for (uint8_t v = 0; v < 3; v++) {
				canal[v].t++;
				if (--canal[v].resta == 0)
					SiguienteNota(&canal[v]);
			}
		}
		s += MuestraEfecto();                /* encima de la música */
		s = s * volumen / 16 + 2048;
		if (s < 0) s = 0;
		if (s > 4095) s = 4095;
		destino[k] = (uint16_t) s;
	}
}
